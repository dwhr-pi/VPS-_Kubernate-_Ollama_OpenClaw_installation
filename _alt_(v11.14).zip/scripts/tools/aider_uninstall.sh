#!/bin/bash
TOOL_NAME="Aider"
TOOL_KEY="Aider"
TOOL_SLUG="aider"
source "$(dirname "$0")/helpers/scaffold_tool_common.sh"
uninstall_scaffold_tool
